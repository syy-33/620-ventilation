# SPDX-FileCopyrightText: Copyright (c) 2020 Bryan Siepert for Adafruit Industries
#
# SPDX-License-Identifier: MIT
"""
`adafruit_scd30`
================================================================================

Helper library for the SCD30 CO2 sensor


* Author(s): Bryan Siepert

Implementation Notes
--------------------

**Hardware:**

* `Adafruit SCD30 Breakout <https://www.adafruit.com/product/4867>`_

**Software and Dependencies:**

* Adafruit CircuitPython firmware for the supported boards:
  https://github.com/adafruit/circuitpython/releases


 * Adafruit's Bus Device library: https://github.com/adafruit/Adafruit_CircuitPython_BusDevice
 * Adafruit's Register library: https://github.com/adafruit/Adafruit_CircuitPython_Register
"""

# imports
import time
from struct import unpack, unpack_from

from adafruit_bus_device import i2c_device
from micropython import const

try:
    from typing import Optional, Union

    from busio import I2C
    from circuitpython_typing import ReadableBuffer
except ImportError:
    pass

__version__ = "2.3.0"
__repo__ = "https://github.com/adafruit/Adafruit_CircuitPython_SCD30.git"
SCD30_DEFAULT_ADDR = 0x61

_CMD_CONTINUOUS_MEASUREMENT = const(0x0010)
_CMD_STOP_CONTINUOUS_MEASUREMENT = const(0x0104)
_CMD_SET_MEASUREMENT_INTERVAL = const(0x4600)
_CMD_GET_DATA_READY = const(0x0202)
_CMD_READ_MEASUREMENT = const(0x0300)
_CMD_AUTOMATIC_SELF_CALIBRATION = const(0x5306)
_CMD_SET_FORCED_RECALIBRATION_FACTOR = const(0x5204)
_CMD_SET_TEMPERATURE_OFFSET = const(0x5403)
_CMD_SET_ALTITUDE_COMPENSATION = const(0x5102)
_CMD_SOFT_RESET = const(0xD304)
_CMD_READ_FIRMWARE_VERSION = const(0xD100)


class SCD30:
    """
    CircuitPython helper class for using the SCD30 CO2 sensor

    :param ~busio.I2C i2c_bus: The I2C bus the SCD30 is connected to.
    :param int ambient_pressure: Ambient pressure compensation. Defaults to :const:`0`
    :param int address: The I2C device address for the sensor. Default is :const:`0x61`

    **Quickstart: Importing and using the SCD30**

        Here is an example of using the :class:`SCD30` class.
        First you will need to import the libraries to use the sensor

        .. code-block:: python

            import board
            import adafruit_scd30

        Once this is done you can define your `board.I2C` object and define your sensor object

        .. code-block:: python

            i2c = board.I2C()   # uses board.SCL and board.SDA
            scd = adafruit_scd30.SCD30(i2c)

        Now you have access to the CO2, temperature and humidity using
        the :attr:`CO2`, :attr:`temperature` and :attr:`relative_humidity` attributes

        .. code-block:: python

            temperature = scd.temperature
            relative_humidity = scd.relative_humidity
            co2_ppm_level = scd.CO2

    .. note::
        `ambient_pressure` default: disabled is written on every construction of this
        object (to start continuous measurement).
        `measurement_interval` defaults to :const:`2` on a new sensor but persists in NVM
        so if changed by your application will persist across power cycles.

    """

    def __init__(
        self, i2c_bus: I2C, ambient_pressure: int = 0, address: int = SCD30_DEFAULT_ADDR
    ) -> None:
        """
        :param ~busio.I2C i2c_bus: The I2C bus the SCD30 is connected to.
        :param int ambient_pressure: Ambient pressure compensation in mBar, :const:`0`
            (disabled) or ``700``-``1400``. Defaults to :const:`0`.
        :param int address: The I2C device address for the sensor. Defaults to :const:`0x61`.
        :raises AttributeError: if `ambient_pressure` is nonzero and outside 700-1400 mBar.
        """
        if ambient_pressure != 0:
            if ambient_pressure < 700 or ambient_pressure > 1400:
                raise AttributeError("`ambient_pressure` must be from 700-1400 mBar")

        self.i2c_device = i2c_device.I2CDevice(i2c_bus, address)
        self._buffer = bytearray(18)
        self._crc_buffer = bytearray(2)

        # start continuous measurements with optional ambient pressure compensation
        self.start_continuous_measurement(ambient_pressure)

        # cached readings
        self._temperature = None
        self._relative_humidity = None
        self._co2 = None

    def start_continuous_measurement(self, pressure_mbar: int = 0) -> None:
        """Start continuous measurement - with optional ambient pressure

        :param int pressure_mbar: the ambient pressure in mbar from 700-1400
        :return: None
        :rtype: None
        """
        pressure_mbar = round(pressure_mbar)
        if pressure_mbar != 0 and (pressure_mbar > 1400 or pressure_mbar < 700):
            raise AttributeError("ambient_pressure must be from 700 to 1400 mBar")
        self._send_command(_CMD_CONTINUOUS_MEASUREMENT, pressure_mbar)

    def stop_continuous_measurement(self) -> None:
        """Stops the continuous measurement of the SCD30

        This is provide for completness.  There is only one SC30 mode: continuous_measurement
        so `stop_continuous_measurement()` freezes measurements at the last measurement.

        :return: None
        :rtype: None
        """
        self._send_command(_CMD_STOP_CONTINUOUS_MEASUREMENT)
        time.sleep(0.1)  # not mentioned by datasheet, but required to avoid IO error

    def reset(self) -> None:
        """Perform a soft reset on the sensor, restoring default values.

        :return: None
        :rtype: None
        """
        self._send_command(_CMD_SOFT_RESET)
        time.sleep(0.1)  # not mentioned by datasheet, but required to avoid IO error

    @property
    def measurement_interval(self) -> int:
        """Sets the interval between readings in seconds. The interval value must be from 2-1800

        .. note::
            This value will be saved in nvm and will persist across powercycles, reboots
            or by calling `reset`.

        :return: the currently configured measurement interval, in seconds
        :rtype: int
        """

        return self._read_register(_CMD_SET_MEASUREMENT_INTERVAL)

    @measurement_interval.setter
    def measurement_interval(self, value: int) -> None:
        """
        :param int value: the measurement interval in seconds, from 2-1800
        :raises AttributeError: if `value` is outside 2-1800
        """
        if value < 2 or value > 1800:
            raise AttributeError("measurement_interval must be from 2-1800 seconds")
        self._send_command(_CMD_SET_MEASUREMENT_INTERVAL, value)

    @property
    def self_calibration_enabled(self) -> bool:
        """Enables or disables automatic self calibration (ASC). To work correctly, the sensor must
        be on and active for 7 days after enabling ASC, and exposed to fresh air for at least 1 hour
        per day. Consult the manufacturer's documentation for more information.

        .. note::
            Enabling self calibration will override any values set by specifying a
            `forced_recalibration_reference`

        .. note::
            This value will be saved and will not be reset on boot or by calling `reset`.

        :return: whether automatic self calibration is currently enabled
        :rtype: bool
        """

        return self._read_register(_CMD_AUTOMATIC_SELF_CALIBRATION) == 1

    @self_calibration_enabled.setter
    def self_calibration_enabled(self, enabled: bool) -> None:
        """
        :param bool enabled: whether to enable automatic self calibration
        """
        self._send_command(_CMD_AUTOMATIC_SELF_CALIBRATION, enabled)
        if enabled:
            time.sleep(0.01)

    @property
    def data_available(self) -> bool:
        """Check the sensor to see if new data is available.

        :return: True if a new measurement is ready to be read
        :rtype: bool
        """
        return bool(self._read_register(_CMD_GET_DATA_READY))

    @property
    def ambient_pressure(self) -> int:
        """Specifies the ambient air pressure at the measurement location in mBar. Setting this
        value adjusts the CO2 measurement calculations to account for the air pressure's effect on
        readings. Values must be in mBar, from 700 to 1400 mBar

        .. note::
            This value is **not** saved and will be reset to 0=disabled on powercycle, boot or
            by calling `reset`.  For non-volatile compensation use altitude instead (saved in nvm)

        :return: the currently configured ambient pressure compensation, in mBar
        :rtype: int
        """
        return self._read_register(_CMD_CONTINUOUS_MEASUREMENT)

    @ambient_pressure.setter
    def ambient_pressure(self, pressure_mbar: int) -> None:
        """
        :param int pressure_mbar: ambient pressure in mBar, :const:`0` (disabled) or
            ``700``-``1400``
        :raises AttributeError: if `pressure_mbar` is nonzero and outside 700-1400 mBar
        """
        # Ambient pressure is set through start_continuous_measurement command
        # bounds checking done there
        self.start_continuous_measurement(pressure_mbar)

    @property
    def altitude(self) -> int:
        """Specifies the altitude at the measurement location in meters above sea level. Setting
        this value adjusts the CO2 measurement calculations to account for the air pressure's effect
        on readings.

        .. note::
            This value is only used when `ambient_pressure` is set to 0=(disabled).
            It is saved in NVR and will not be reset on boot, reset or powercycle.

        :return: the currently configured altitude compensation, in meters above sea level
        :rtype: int
        """
        return self._read_register(_CMD_SET_ALTITUDE_COMPENSATION)

    @altitude.setter
    def altitude(self, altitude: int) -> None:
        """
        :param int altitude: altitude in meters above sea level
        """
        self._send_command(_CMD_SET_ALTITUDE_COMPENSATION, int(altitude))

    @property
    def temperature_offset(self) -> float:
        """Specifies the offset to be added to the reported measurements to account for a bias in
        the measured signal. Value is in degrees Celsius with a resolution of 0.01 degrees and a
        maximum value of 655.35 C

        .. note::
            This value will be saved and will not be reset on boot or by calling `reset`.

        :return: the currently configured temperature offset, in degrees Celsius
        :rtype: float
        """

        raw_offset = self._read_register(_CMD_SET_TEMPERATURE_OFFSET)
        return raw_offset / 100.0

    @temperature_offset.setter
    def temperature_offset(self, offset: Union[float, int]) -> None:
        """
        :param offset: offset in degrees Celsius, from 0 to 655.35 (0.01 C resolution)
        :type offset: float or int
        :raises AttributeError: if `offset` is negative or greater than 655.35 degrees Celsius
        """
        if offset < 0 or offset > 655.35:
            raise AttributeError("Offset value must be from 0 to 655.35 degrees Celsius")
        self._send_command(_CMD_SET_TEMPERATURE_OFFSET, round(offset * 100))

    @property
    def forced_recalibration_reference(self) -> int:
        """Specifies the concentration of a reference source of CO2 placed in close proximity to the
        sensor. The value must be from 400 to 2000 ppm.

        .. note::
            Specifying a forced recalibration reference will override any calibration values
            set by Automatic Self Calibration

        .. warning::
            Before applying, the sensor should be running in continuous measurement mode, at
            the default 2 second interval, in a stable known-CO2 environment, for at least 2
            minutes. This permanently updates the sensor's calibration curve.

        :return: the currently configured forced recalibration reference, in ppm
        :rtype: int
        """
        return self._read_register(_CMD_SET_FORCED_RECALIBRATION_FACTOR)

    @forced_recalibration_reference.setter
    def forced_recalibration_reference(self, reference_value: int) -> None:
        """
        :param int reference_value: reference CO2 concentration in ppm, from 400 to 2000
        :raises AttributeError: if `reference_value` is outside 400-2000 ppm
        """
        if reference_value < 400 or reference_value > 2000:
            raise AttributeError("forced_recalibration_reference must be from 400 to 2000 ppm")
        self._send_command(_CMD_SET_FORCED_RECALIBRATION_FACTOR, reference_value)

    @property
    def CO2(self) -> float:  # pylint:disable=invalid-name
        """Returns the CO2 concentration in PPM (parts per million)

        .. note::
            Between measurements, the most recent reading will be cached and returned. If
            called before the first measurement has completed, returns :const:`None`.

        :return: CO2 concentration in ppm, or None if no measurement has completed yet
        :rtype: float or None
        """
        if self.data_available:
            self._read_data()
        return self._co2

    @property
    def temperature(self) -> float:
        """Returns the current temperature in degrees Celsius

        .. note::
            Between measurements, the most recent reading will be cached and returned. If
            called before the first measurement has completed, returns :const:`None`.

        :return: temperature in degrees Celsius, or None if no measurement has completed yet
        :rtype: float or None
        """
        if self.data_available:
            self._read_data()
        return self._temperature

    @property
    def relative_humidity(self) -> float:
        """Returns the current relative humidity in %rH.

        .. note::
            Between measurements, the most recent reading will be cached and returned. If
            called before the first measurement has completed, returns :const:`None`.

        :return: relative humidity in %rH, or None if no measurement has completed yet
        :rtype: float or None
        """
        if self.data_available:
            self._read_data()
        return self._relative_humidity

    @property
    def firmware_version(self) -> str:
        """Returns the firmware version of the sensor.  Can also be used to check
        whether sensor is present and responding.

        :return: the sensor firmware version major/minor rev
        :rtype: str
        """
        # Datasheet example lists V3.66
        fwver = self._read_register(_CMD_READ_FIRMWARE_VERSION)
        return f"{fwver >> 8:1d}.{fwver & 0xFF:1d}"

    def _send_command(self, command: int, arguments: Optional[int] = None) -> None:
        # if there is an argument, calculate the CRC and include it as well.
        if arguments is not None:
            self._crc_buffer[0] = arguments >> 8
            self._crc_buffer[1] = arguments & 0xFF
            self._buffer[2] = arguments >> 8
            self._buffer[3] = arguments & 0xFF
            crc = self._crc8(self._crc_buffer)
            self._buffer[4] = crc
            end_byte = 5
        else:
            end_byte = 2

        self._buffer[0] = command >> 8
        self._buffer[1] = command & 0xFF

        with self.i2c_device as i2c:
            i2c.write(self._buffer, end=end_byte)
        # Datasheet requires >3ms between a write and any following read
        time.sleep(0.050)  # This is a safe number lower numbers have timeouts

    def _read_register(self, reg_addr: int) -> int:
        self._buffer[0] = reg_addr >> 8
        self._buffer[1] = reg_addr & 0xFF
        with self.i2c_device as i2c:
            i2c.write(self._buffer, end=2)
            # separate readinto because the SCD30 wants an i2c stop before the read
            # (non-repeated start)
            time.sleep(0.010)  # doubled due to occasional timeouts
            i2c.readinto(self._buffer, end=3)
        if not self._check_crc(self._buffer[:2], self._buffer[2]):
            raise RuntimeError("CRC check failed while reading data")
        return unpack_from(">H", self._buffer[0:2])[0]

    def _read_data(self) -> None:
        self._send_command(_CMD_READ_MEASUREMENT)
        with self.i2c_device as i2c:
            i2c.readinto(self._buffer)

        crcs_good = True

        for i in range(0, 18, 3):
            crc_good = self._check_crc(self._buffer[i : i + 2], self._buffer[i + 2])
            if crc_good:
                continue
            crcs_good = False
        if not crcs_good:
            raise RuntimeError("CRC check failed while reading data")

        self._co2 = unpack(">f", self._buffer[0:2] + self._buffer[3:5])[0]
        self._temperature = unpack(">f", self._buffer[6:8] + self._buffer[9:11])[0]
        self._relative_humidity = unpack(">f", self._buffer[12:14] + self._buffer[15:17])[0]

    def _check_crc(self, data_bytes: ReadableBuffer, crc: int) -> bool:
        return crc == self._crc8(bytearray(data_bytes))

    @staticmethod
    def _crc8(buffer: bytearray) -> int:
        crc = 0xFF
        for byte in buffer:
            crc ^= byte
            for _ in range(8):
                if crc & 0x80:
                    crc = (crc << 1) ^ 0x31
                else:
                    crc <<= 1
        return crc & 0xFF  # return the bottom 8 bits
